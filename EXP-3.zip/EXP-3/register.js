function validate() {
  const { fname, lname, phone, pwd, mailid } = frm;

  const nameCheck = name => /^[A-Za-z]+$/.test(name);
  if (!nameCheck(fname.value))
     return alert("Invalid firstname"), false;
  if (!nameCheck(lname.value)) 
    return alert("Invalid lastname"), false;

  if (phone.value.length !== 10) 
    return alert("Phone no should be exactly 10 digits"), false;

  const pw = pwd.value;
  if (pw.length % 2 !== 0) 
    return alert("Password should contain even number of characters"), false;
  if (pw.length > 8) 
    return alert("Password should not exceed 8 digits"), false;

  const emailRegex = /^\w+([-.']?\w+)*@\w+([-.]?\w+)*\.\w+([-.]?\w+)*$/;
  if (!emailRegex.test(mailid.value)) 
    return alert("Invalid email"), false;

  localStorage.setItem("firstname", fname.value);
  localStorage.setItem("lastname", lname.value);
  localStorage.setItem("phone", phone.value);
  localStorage.setItem("password", pw);
  localStorage.setItem("email", mailid.value);

  alert("Registration Successful!!");
  return true;
}
