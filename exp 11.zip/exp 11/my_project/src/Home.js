import React from 'react';
function Home(){
    return (
        <div>
            <h1>Home page</h1>
            <p>Learn more Home on this page</p>
        </div>
    );
}
export default Home;