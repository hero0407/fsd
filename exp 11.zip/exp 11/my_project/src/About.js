import React from 'react';
function About(){
    return (
        <div>
            <h1>About page</h1>
            <p>Learn more About on this page</p>
        </div>
    );
}
export default About;
