import React from 'react';
function Contact(){
    return (
        <div>
            <h1>Contact page</h1>
            <p>Learn more Contact on this page</p>
        </div>
    );
}
export default Contact;